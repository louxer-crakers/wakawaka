# Environment Variables

`DB_HOST=[RDS endpoint]`<br/>
`DB_NAME=ordersdb`<br/>
`DB_USER=dbadmin`<br/>
`DB_PASSWORD=yourpassword`<br/>


# Dependencies

``